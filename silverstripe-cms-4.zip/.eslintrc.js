module.exports = require('@silverstripe/eslint-config/.eslintrc');
