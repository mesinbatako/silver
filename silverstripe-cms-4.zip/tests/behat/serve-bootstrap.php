<?php

require __DIR__ . '/../bootstrap/init.php';
require FRAMEWORK_PATH . '/tests/bootstrap/init.php';
require FRAMEWORK_PATH . '/tests/bootstrap/environment.php';
require __DIR__ . '/../bootstrap/app.php';
